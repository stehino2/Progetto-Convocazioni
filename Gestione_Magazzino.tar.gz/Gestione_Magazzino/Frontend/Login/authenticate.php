<?php
// Includo i parametri per poter accedere al database
 include("parametri.php");

 // Mi connetto al database
 $connect = mysqli_connect($server, $username, $password)
  or die("Connessione non riuscita: " . mysqli_error($connect));

 mysqli_select_db($connect, $database)
  or die("Impossibile selezionare il db");

 $table = "2401_db_Utenti";

 // Recupero l'username e la password inseriti
 if (isset($_REQUEST['user']) && isset($_REQUEST['password'])) {
	$user = $_REQUEST['user'];
	$password = $_REQUEST['password'];

    /* Cerco nella tabella degli utenti se l'utente inserito esiste,
    se non esiste ritorno un errore */
	$query = "SELECT * FROM $table WHERE Username='$user' AND Passw='$password'";
    $result = mysqli_query($connect, $query)
     or die("Errore nella query" . mysqli_error($connect));

    if (mysqli_num_rows($result) > 0) {
        // L'utente esiste, recupero le informazioni
        $row = mysqli_fetch_assoc($result);
        
        // Verifico il ruolo dell'utente e reindirizzo in base al ruolo
        if ($row['Ruolo'] == 'Amministratore') {
            // Reindirizzo l'amministratore a una pagina specifica
            header("Location: pagina_amministratore.php");
            exit();
        } elseif ($row['Ruolo'] == 'Magaziniere') {
            // Reindirizzo il magazziniere a un'altra pagina specifica
            header("Location: pagina_magaziniere.php");
            exit();
        }
    } else {
        die("Credenziali non valide");
    }
} else {
    /* La funzione header è utilizzata per inviare un'intestazione HTTP 
     * al client durante l'esecuzione di uno script. Le intestazioni HTTP 
     * contengono informazioni che il server invia al browser del client 
     * prima di inviare il corpo della risposta. Tale funzione consente 
     * di controllare vari aspetti della comunicazione tra il server e 
     * il client, inclusi i reindirizzamenti, i cookie e le cache. */
    header('WWW-Authenticate: Basic realm="Restricted Area"');
    header('HTTP/1.0 401 Unauthorized');
    die("Please enter your username and password");
}
?>
