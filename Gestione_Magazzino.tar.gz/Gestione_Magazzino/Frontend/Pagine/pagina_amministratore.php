<?php
 // Pagina dove l'amministratore sceglie cosa vuole fare
 echo '<a href="elenco_articoli.php"><button>Elenco Articoli</button></a>
 <a href="movimenti_magazzino.php"><button>Movimenti Magazzino</button></a>
 <a href="consultazione_magazzino.php"><button>Consulta Magazzino</button></a>
 <a href="gestione_magazzino.php"><button>Gestione Magazzino</button></a>'; 
?>