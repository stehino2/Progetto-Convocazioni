<?php
 // Dati per accedere al database
 $server = "localhost"; // host del database
 $username = "s02677"; // utente che accede al db
 $password = "Aachie";
 $database = "s02677"; // nome del database
?>

