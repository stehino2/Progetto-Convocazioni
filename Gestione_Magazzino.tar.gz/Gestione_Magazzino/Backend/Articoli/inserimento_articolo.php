<?php
 // Includo i parametri per poter accedere al database
 include("parametri.php");

 // Mi connetto al database
 $connect = mysqli_connect($server, $username, $password)
  or die("Connessione non riuscita: " . mysqli_error($connect));

 mysqli_select_db($connect, $database)
  or die("Impossibile selezionare il db");

 // Stampo il titolo della pagina e le textbox dove inserire i dati
 echo "<html><head><title>Inserimento Articolo</title></head><body>";
 echo "<h1>Inserisci un nuovo articolo</h1>";

 echo '<form method="post" action="inserimento_articolo.php">
       <label for="CodiceArticolo">CodiceArticolo:</label>
       <input type="text" name="CodiceArticolo" required><br>

       <label for="Descrizione">Descrizione:</label>
       <input type="text" name="Descrizione" required><br>

       <label for="Locazione">Locazione:</label>
       <input type="text" name="Locazione" required><br>

       <label for="Costo">Costo:</label>
       <input type="number" name="Costo" required><br>

       <input type="submit" value="Inserisci"></form>
       <p><a href="elenco_articoli.php">Torna agli articoli</a></p>';

 echo "</body></html>";

 // Controllo se il modulo di inserimento è stato inviato
 if($_SERVER["REQUEST_METHOD"] == "POST") {
  $CodiceArticolo = $_POST["CodiceArticolo"];
  $Descrizione = $_POST["Descrizione"];
  $Locazione = $_POST["Locazione"];
  $Costo = $_POST["Costo"];

  // Recupero il valore della variabile $table
  $table = isset($_GET['table']) ? mysqli_real_escape_string($connect, $_GET['table']) : "";

  // Verifico se il CodiceArticolo è già presente nel database
  $checkCodiceArticoloQuery = "SELECT CodiceArticolo FROM 2401_db_Articolo WHERE CodiceArticolo = '$CodiceArticolo'";
  $resultCodiceArticolo = mysqli_query($connect, $checkCodiceArticoloQuery);

  /* Invio un messaggio di errore se l'articolo si trova già
  all'interno del database, altrimenti inserisco il nuovo
  articolo nel database e restituisco un messaggio di
  avvenuto inserimento dell'articolo */
  if(mysqli_num_rows($resultCodiceArticolo) > 0) {
    echo "Errore: CodiceArticolo già esistente nel database.";
  } else {
    $query = "INSERT INTO 2401_db_Articolo (CodiceArticolo, Descrizione, Locazione, Costo) 
    VALUES ('$CodiceArticolo', '$Descrizione', '$Locazione', '$Costo')";

    if(mysqli_query($connect, $query)) {
        echo "Nuovo articolo inserito con successo.";
    } else {
        echo "Errore durante l'inserimento dell'articolo: " . mysqli_error($connect);
    }
  }
 }

 // Libero il buffer
 //mysqli_free_result($result);
 mysqli_close($connect);
?>