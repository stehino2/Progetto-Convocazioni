<?php
 // Includo i parametri per poter accedere al database
 include("parametri.php");

 // Mi connetto al database
 $connect = mysqli_connect($server, $username, $password)
  or die("Connessione non riuscita: " . mysqli_error($connect));

 mysqli_select_db($connect, $database)
  or die("Impossibile selezionare il db");

 // Ottengo il codice articolo dall'url
 $articolo_id = $_GET['id'];

 // Query di eliminazione
 $query_elimina = "DELETE FROM 2401_db_Articolo WHERE CodiceArticolo = '$articolo_id'";
 $result_elimina = mysqli_query($connect, $query_elimina);

 if ($result_elimina) {
    echo "<html><head><title>Inserimento Articolo</title></head><body>";
    echo "Articolo eliminato con successo.";
    echo '<p><a href="elenco_articoli.php">Torna agli articoli</a></p></body></html>';
 } else {
    echo "Errore durante l'eliminazione dell'articolo: " . mysqli_error($connect);
 }

 // Chiudo la connessione
 mysqli_close($connect);
?>
