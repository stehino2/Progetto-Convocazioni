<?php
 // Includo i parametri per poter accedere al database
 include("parametri.php");

 // Mi connetto al database
 $connect = mysqli_connect($server, $username, $password)
  or die("Connessione non riuscita: " . mysqli_error($connect));

 mysqli_select_db($connect, $database)
  or die("Impossibile selezionare il db");

 // Seleziono la tabella di mio interesse e mi connetto ad essa
 $table = "2401_db_Movimenti";
 $query = "SELECT * FROM " . $table;
 $result = mysqli_query($connect, $query)
  or die("Errore nella query" . mysqli_error($connect));

 // Stampo il titolo della pagina e il nome delle colonne della tabella
 echo "<html><head><title>Movimenti Magazzino</title></head><body>";
 echo "<h1>Movimenti Magazzino</h1>";

 echo '<a href="elenco_articoli.php"><button type="button">Vai alla lista articoli</button></a>';
 echo '<a href="consultazione_magazzino.php"><button>Consulta Magazzino</button></a>';
 
 echo "<table border='1'>";
 echo "<tr>";
 echo '<th>Codice Articolo</th>
       <th>Codice Movimento</th>
       <th>Data</th>
       <th>Tipo Movimento</th>
       <th>Quantità</th>
       <th><a href="inserimento_movimenti.php"><button type="button">Inserisci Nuovo Movimento</button></a></th>';
 echo "</tr>";

 // Stampo i dati della tabella
 while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>{$row['CodiceArticolo']}</td>";
    echo "<td>{$row['CodiceMovimento']}</td>";
    echo "<td>{$row['Data']}</td>";
    echo "<td>{$row['TipoMovimento']}</td>";
    echo "<td>{$row['Quantità']}</td>";
    // Aggiungo anche due pulsanti per modificare ed eliminare gli articoli
    echo "<td><a href='modifica_movimenti.php?id={$row['CodiceArticolo']}'><button type='button'>Modifica</button></a>
    <a href='cancella_movimenti.php?id={$row['CodiceArticolo']}'><button type='button'>Elimina</button></a></td>";
    echo "</tr>";
 }

 echo "</table></body></html>";

 // Libero il buffer
 mysqli_free_result($result);
 mysqli_close($connect);
?>