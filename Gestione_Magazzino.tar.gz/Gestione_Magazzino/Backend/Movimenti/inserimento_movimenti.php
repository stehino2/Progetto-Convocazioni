<?php
 // Includo i parametri per poter accedere al database
 include("parametri.php");

 // Mi connetto al database
 $connect = mysqli_connect($server, $username, $password)
  or die("Connessione non riuscita: " . mysqli_error($connect));

 mysqli_select_db($connect, $database)
  or die("Impossibile selezionare il db");

 // Stampo il titolo della pagina e le textbox dove inserire i dati
 echo "<html><head><title>Inserimento Movimento</title></head><body>";
 echo "<h1>Inserisci un nuovo movimento</h1>";

 echo '<form method="post" action="inserimento_movimenti.php">
       <label for="CodiceArticolo">CodiceArticolo:</label>
       <input type="text" name="CodiceArticolo" required><br>

       <label for="CodiceMovimento">Codice Movimento:</label>
       <input type="text" name="CodiceMovimento" required><br>

       <label for="Data">Data:</label>
       <input type="date" name="Data" required><br>

       <label for="TipoMovimento">Tipo Movimento:</label>
       <select name="TipoMovimento" required>
        <option value="Carico">Carico</option>
        <option value="Scarico">Scarico</option>
       </select><br>

       <label for="Quantita">Quantità:</label>
       <input type="number" name="Quantita" required><br>

       <input type="submit" value="Inserisci"></form>
       <p><a href="movimenti_magazzino.php">Torna ai movimenti magazzino</a></p>';

 echo "</body></html>";

 // Controllo se il modulo di inserimento è stato inviato
 if($_SERVER["REQUEST_METHOD"] == "POST") {
  $CodiceArticolo = $_POST["CodiceArticolo"];
  $CodiceMovimento = $_POST["CodiceMovimento"];
  $Data = $_POST["Data"];
  $TipoMovimento = $_POST["TipoMovimento"];
  $Quantita = $_POST["Quantita"];

  // Recupero il valore della variabile $table
  $table = isset($_GET['table']) ? mysqli_real_escape_string($connect, $_GET['table']) : "";

  /* Verifico se il codice articolo è presente all'interno
  della tabella articoli, altrimenti non aggiungo il movimento */
  $checkCodiceArticoloQuery = "SELECT CodiceArticolo FROM 2401_db_Articolo WHERE CodiceArticolo = '$CodiceArticolo'";
  $resultCodiceArticolo = mysqli_query($connect, $checkCodiceArticoloQuery);

  /* Invio un messaggio di errore se l'articolo si trova già
  all'interno del database, altrimenti inserisco il nuovo
  articolo nel database e restituisco un messaggio di
  avvenuto inserimento dell'articolo */
  if(mysqli_num_rows($resultCodiceArticolo) > 0) {
    $query = "INSERT INTO 2401_db_Movimenti (CodiceArticolo, CodiceMovimento, Data, TipoMovimento, Quantità) 
    VALUES ('$CodiceArticolo', '$CodiceMovimento', '$Data', '$TipoMovimento', '$Quantita')";
    if(mysqli_query($connect, $query)) {
        echo "Nuovo movimento inserito con successo.";
    } else {
        echo "Errore durante l'inserimento del movimento: " . mysqli_error($connect);
    }
  } else {
    echo "Errore: CodiceArticolo non esistente negli articoli.";
  }
 }

 // Libero il buffer
 //mysqli_free_result($result);
 mysqli_close($connect);
?>