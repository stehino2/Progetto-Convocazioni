<?php
 // Includo i parametri per poter accedere al database
 include("parametri.php");

 // Mi connetto al database
 $connect = mysqli_connect($server, $username, $password)
  or die("Connessione non riuscita: " . mysqli_error($connect));

 mysqli_select_db($connect, $database)
  or die("Impossibile selezionare il db");

 // Seleziono la tabella di mio interesse e mi connetto ad essa
 $table = "2401_db_Magazzino";
 $query = "SELECT * FROM " . $table;
 $result = mysqli_query($connect, $query)
  or die("Errore nella query" . mysqli_error($connect));

 // Stampo il titolo della pagina e il nome delle colonne della tabella
 echo "<html><head><title>Elenco Magazzino</title></head><body>";
 echo "<h1>Magazzino</h1>";
 echo "<table border='1'>";
 echo "<tr>";
 echo "<th>Codice Articolo</th>
       <th>Descrizione</th>
       <th>Quantità</th>
       <th>Prezzo</th>";
 echo "</tr>";

 // Stampo i dati della tabella
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>{$row['CodiceArticolo']}</td>";
    echo "<td>{$row['Descrizione']}</td>";
    echo "<td>{$row['Quantità']}</td>";
    echo "<td>{$row['Prezzo']}</td>";
    echo "</tr>";
 }

 echo "</table></body></html>";

 // Libero il buffer
 mysqli_free_result($result);
 mysqli_close($connect);
?>